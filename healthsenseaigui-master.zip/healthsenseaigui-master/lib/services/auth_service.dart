// /Users/username/path/to/healthsenseaigui/lib/services/auth_service.dart

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:healthsenseaigui/utils/route_names.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Sign in with email and password
  Future<void> signInWithEmailAndPassword({
    required String email,
    required String password,
    required BuildContext context, // Add context for navigation
  }) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);

      // Navigate to the home screen after successful login
      Navigator.pushReplacementNamed(context, RouteNames.home);

    } on FirebaseAuthException catch (e) {
      // Handle the error.
      print('Error during sign in: ${e.message}');

      // Example: Displaying an error message using a SnackBar
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.message}')),
      );
    }
  }

  // Sign up with email and password
  Future<void> signUpWithEmailAndPassword({
    required String email,
    required String password,
    required BuildContext context, // Add context for navigation
  }) async {
    try {
      await _auth.createUserWithEmailAndPassword(email: email, password: password);

      // Navigate to the home screen after successful signup
      Navigator.pushReplacementNamed(context, RouteNames.home);

    } on FirebaseAuthException catch (e) {
      // Handle the error.
      print('Error during sign up: ${e.message}');

      // Example: Displaying an error message using a SnackBar
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.message}')),
      );
    }
  }

  // Sign out
  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } on FirebaseAuthException catch (e) {
      // Handle the error.
      print('Error during sign out: ${e.message}');
    }
  }
}
