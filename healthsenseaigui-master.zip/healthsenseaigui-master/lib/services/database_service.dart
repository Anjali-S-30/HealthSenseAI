import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // ... other database methods

  // Example: Get User's Name
  Future<String?> getUserName() async {
    try {
      User? user = _auth.currentUser;
      if (user != null) {
        DocumentSnapshot userSnapshot = await _firestore
            .collection('users')
            .doc(user.uid)
            .get();
        return userSnapshot.get('name') as String?;
      }
    } catch (e) {
      print("Error getting user name: $e");
      return null;
    }
    return null;
  }

  // Example: Get User Data
  Future<Map<String, dynamic>?> getUserData() async {
    try {
      User? user = _auth.currentUser;
      if (user != null) {
        DocumentSnapshot userSnapshot =
        await _firestore.collection('users').doc(user.uid).get();
        return userSnapshot.data() as Map<String, dynamic>?;
      }
    } catch (e) {
      print("Error getting user data: $e");
      return null;
    }
    return null;
  }

  // Example: Update User Data
  Future<void> updateUserData(Map<String, dynamic> data) async {
    try {
      User? user = _auth.currentUser;
      if (user != null) {
        await _firestore.collection('users').doc(user.uid).set(data, SetOptions(merge: true));
      }
    } catch (e) {
      print("Error updating user data: $e");
    }
  }

  // Example: Get Health Data
  Future<Map<String, dynamic>?> getHealthData() async {
    try {
      User? user = _auth.currentUser;
      if (user != null) {
        DocumentSnapshot healthSnapshot = await _firestore
            .collection('users')
            .doc(user.uid)
            .collection('health_details')
            .doc('user_health')
            .get();

        if (healthSnapshot.exists) {
          return healthSnapshot.data() as Map<String, dynamic>?;
        } else {
          return{};
        }
      }
    } catch (e) {
      print("Error getting health data: $e");
      rethrow;
    }
    return null;
  }

  // Example: Update Health Data
  Future<void> updateHealthData(Map<String, dynamic> data) async {
    try {
      User? user = _auth.currentUser;
      if (user != null) {
        await _firestore
            .collection('users')
            .doc(user.uid)
            .collection('health_details')
            .doc('user_health')
            .set(data, SetOptions(merge: true));
      }
    } catch (e) {
      print("Error updating health data: $e");
      rethrow;
    }
  }
}
