import 'package:flutter/material.dart';

class PillsInfoScreen extends StatelessWidget {
  const PillsInfoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Pills Info"),
          bottom: const TabBar(
            tabs: [
              Tab(text: "Pills Information"),
              Tab(text: "Pills Identification"),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            Center(child: Text("Pills Information Content")),
            Center(child: Text("Pills Identification Content")),
          ],
        ),
      ),
    );
  }
}
