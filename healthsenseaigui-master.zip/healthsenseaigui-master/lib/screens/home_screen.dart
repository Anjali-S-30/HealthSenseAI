import 'package:flutter/material.dart';
import 'package:healthsenseaigui/screens/alerts_screen.dart';
import 'package:healthsenseaigui/screens/dashboard_screen.dart';
import 'package:healthsenseaigui/screens/diagno_assist_screen.dart';
import 'package:healthsenseaigui/screens/health_details_screen.dart';
import 'package:healthsenseaigui/screens/health_schemes_screen.dart';
import 'package:healthsenseaigui/screens/login_screen.dart';
import 'package:healthsenseaigui/screens/pills_info_screen.dart';
import 'package:healthsenseaigui/screens/profile_screen.dart';
import 'package:healthsenseaigui/services/auth_service.dart'; // Import your AuthService

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Add your screens here
  static final List<Widget> _screens = <Widget>[
    const DashboardScreen(),
    const PillsInfoScreen(),
    const DiagnoAssistScreen(),
    const HealthSchemesScreen(),
    const AlertsScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text("Health-Sense AI"),
        leading: IconButton(
          icon: const Icon(Icons.account_circle),
          onPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Color(0xFF33CCE3)),
              child:
              const Text("Menu", style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text("Profile"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ProfileScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.health_and_safety),
              title: const Text("Health Details"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const HealthDetailsScreen()),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.exit_to_app),
              title: const Text("Logout"),
              onTap: () async {
                // Handle logout logic here
                await AuthService().signOut();
                // After signing out, navigate back to login
                if (mounted) {
                  Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(
                          builder: (context) => LoginPage()),
                          (Route<dynamic> route) => false);
                }
              },
            ),
          ],
        ),
      ),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF0FA5BF),
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: "Dashboard"),
          BottomNavigationBarItem(icon: Icon(Icons.medication), label: "Pills Info"),
          BottomNavigationBarItem(
              icon: Icon(Icons.medical_information), label: "DiagnoAssist"),
          BottomNavigationBarItem(
              icon: Icon(Icons.local_hospital), label: "Health Scheme"),
          BottomNavigationBarItem(icon: Icon(Icons.warning), label: "Alerts"),
        ],
      ),
    );
  }
}
