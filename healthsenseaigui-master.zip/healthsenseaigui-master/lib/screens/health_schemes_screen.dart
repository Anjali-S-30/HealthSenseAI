import 'package:flutter/material.dart';

class HealthSchemesScreen extends StatelessWidget {
  const HealthSchemesScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("Health Schemes Screen"));
  }
}
