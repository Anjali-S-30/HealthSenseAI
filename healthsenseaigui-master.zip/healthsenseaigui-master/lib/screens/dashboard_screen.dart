import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:healthsenseaigui/services/database_service.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart'; // For the chart example

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String? _userName = '';
  String? _height = '';
  String? _weight = '';
  String? _bmi = '';
  String _healthTip = 'Loading health tip...';
  List<HealthData> _chartData = []; // Store chart data


  @override
  void initState() {
    super.initState();
    _fetchUserData();
    _fetchHealthData();
    _fetchDailyHealthTip();
    _fetchWeightChartData();
  }

  Future<void> _fetchUserData() async {
    try {
      Map<String, dynamic>? userData =
      await DatabaseService().getUserData();
      setState(() {
        _userName = userData?['name'] ?? "";
      });
    } catch (e) {
      print("Error fetching user data: $e");
    }
  }

  Future<void> _fetchHealthData() async {
    try {
      Map<String, dynamic>? healthData =
      await DatabaseService().getHealthData();
      setState(() {
        _height = healthData?['height'] ?? "";
        _weight = healthData?['weight'] ?? "";
        _bmi = healthData?['bmi'] ?? "";
      });
    } catch (e) {
      print("Error fetching health data: $e");
    }
  }

  Future<void> _fetchWeightChartData() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final snapshot = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .collection('weight_records') // Assuming 'weight_records' subcollection
            .orderBy('date', descending: true) // Order by date to get the latest week
            .limit(7) // Get data for the last 7 days
            .get();

        setState(() {
          _chartData = snapshot.docs.map((doc) {
            final data = doc.data();
            return HealthData(
              date: (data['date'] as Timestamp).toDate(),
              weight: double.parse(data['weight'].toString()),
            );
          }).toList();
        });
      }
    } catch (e) {
      print("Error fetching chart data: $e");
      // Handle error, perhaps show a message to the user
    }
  }

  // Implement the _fetchDailyHealthTip to fetch and update the health tip
  Future<void> _fetchDailyHealthTip() async {
    try {
      final response = await http.get(Uri.parse('https://api.adviceslip.com/advice'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _healthTip = data['slip']['advice'];
        });
      } else {
        // Handle API error, perhaps show a default tip
        setState(() {
          _healthTip = "Error loading health tip. Stay hydrated!";
        });
        print('Error: ${response.statusCode}');
      }
    } catch (e) {
      // Handle network or other errors
      setState(() {
        _healthTip = "Error loading health tip. Stay hydrated!";
      });
      print('Error: $e');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dashboard")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Welcome back, $_userName!",
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),
            // Display basic user health info
            _buildHealthInfoCard(),

            const SizedBox(height: 20),
            // Placeholder for graph analysis
            _buildHealthChart(),

            const SizedBox(height: 20),
            // Display daily health tips
            _buildHealthTipCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildHealthInfoCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Your Health Summary",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            _buildHealthInfoRow(Icons.accessibility, "Height", "$_height cm"),
            _buildHealthInfoRow(Icons.scale, "Weight", "$_weight kg"),
            _buildHealthInfoRow(Icons.monitor_weight, "BMI", "$_bmi"),
          ],
        ),
      ),
    );
  }
  Widget _buildHealthInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, color: Color(0xFF0FA58F)), // Customizable icon color
          const SizedBox(width: 8),
          Text(
            "$label: ",
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(value),
        ],
      ),
    );
  }

  Widget _buildHealthChart() {
    return Card(
      child: SizedBox(
        height: 200,
        child: SfCartesianChart(
          primaryXAxis: DateTimeAxis(
            dateFormat: DateFormat('E'), // Display day of the week ('Mon', 'Tue', etc.)
            majorGridLines: const MajorGridLines(width: 0),
          ),
          primaryYAxis: NumericAxis(
            title: AxisTitle(text: 'Weight (kg)'),
            minimum: 40, // Set a suitable minimum for your data
            maximum: 80, // Set a suitable maximum
            interval: 5,
          ),
          tooltipBehavior: TooltipBehavior(enable: true),
          series: <CartesianSeries>[
            LineSeries<HealthData, DateTime>(
              dataSource: _chartData,
              xValueMapper: (HealthData data, _) => data.date,
              yValueMapper: (HealthData data, _) => data.weight,
              dataLabelSettings: const DataLabelSettings(isVisible: true),
            )
          ],
        ),
      ),
    );
  }


  Widget _buildHealthTipCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Daily Health Tip",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(_healthTip),
          ],
        ),
      ),
    );
  }
}

class HealthData {
  final DateTime date;
  final double weight;

  HealthData({required this.date, required this.weight});
}
