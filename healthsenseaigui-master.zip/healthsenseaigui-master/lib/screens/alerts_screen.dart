import 'package:flutter/material.dart';

class AlertsScreen extends StatelessWidget {
  const AlertsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Alerts"),
          bottom: const TabBar(
            tabs: [
              Tab(text: "Pills Reminder"),
              Tab(text: "Dosage Reminder"),
              Tab(text: "Water Intake Reminder"),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            Center(child: Text("Pills Reminder Content")),
            Center(child: Text("Dosage Reminder Content")),
            Center(child: Text("Water Intake Reminder Content")),
          ],
        ),
      ),
    );
  }
}
