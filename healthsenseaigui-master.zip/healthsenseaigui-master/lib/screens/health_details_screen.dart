import 'package:flutter/material.dart';
import 'package:healthsenseaigui/services/database_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';


class HealthDetailsScreen extends StatefulWidget {
  const HealthDetailsScreen({Key? key}) : super(key: key);

  @override
  State<HealthDetailsScreen> createState() => _HealthDetailsScreenState();
}

class _HealthDetailsScreenState extends State<HealthDetailsScreen> {
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _bmiController = TextEditingController();
  final TextEditingController _conditionsController = TextEditingController();
  final TextEditingController _allergiesController = TextEditingController();
  final TextEditingController _medicationsController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;
  DateTime? _selectedDate;
  List<Map<String, dynamic>> _doctorVisits = [];
  @override
  void initState() {
    super.initState();
    _fetchHealthData();
    _heightController.addListener(_calculateBMI);
    _weightController.addListener(_calculateBMI);
    _doctorVisits = [{}];
  }

  @override
  void dispose() {
    _heightController.dispose();
    _weightController.dispose();
    _bmiController.dispose();
    _conditionsController.dispose();
    _allergiesController.dispose();
    _medicationsController.dispose();
    super.dispose();
  }
  void _calculateNextCheckupDate(int daysToAdd, int index) {
    // Get the stored lastCheckupDate from the _doctorVisits list
    DateTime? lastCheckupDate = _doctorVisits[index]['lastCheckupDate'] != null
        ? (_doctorVisits[index]['lastCheckupDate'] as Timestamp).toDate()
        : null;

    if (lastCheckupDate != null) {
      DateTime nextCheckupDate = lastCheckupDate.add(Duration(days: daysToAdd));
      // Update the specific doctor visit entry in the list
      _doctorVisits[index]['nextCheckup'] =
          DateFormat('dd-MM-yyyy').format(nextCheckupDate);
      setState(() {}); // Rebuild the UI to reflect the change
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select the last checkup date first.')),
      );
    }
  }



  Future<void> _fetchHealthData() async {
    setState(() => _isLoading = true);
    try {
      Map<String, dynamic>? healthData =
      await DatabaseService().getHealthData();
      setState(() {
        _heightController.text = healthData?['height'] != null
            ? healthData!['height'].toString()
            : "";
        _weightController.text = healthData?['weight'] != null
            ? healthData!['weight'].toString()
            : "";
        _bmiController.text = healthData?['bmi'] ?? "";
        _conditionsController.text = healthData?['conditions'] ?? "";
        _allergiesController.text = healthData?['allergies'] ?? "";
        _medicationsController.text = healthData?['medications'] ?? "";


        // If checkup date is stored as a timestamp in Firestore,
        // convert it to DateTime
        if (healthData?['doctorVisits'] != null) {
          _doctorVisits = List<Map<String, dynamic>>.from(healthData!['doctorVisits']);
        } else{
          _doctorVisits = [{}];
        }
      });
    } catch (e) {
      print("Error fetching health data: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to load health details.')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveChanges() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      await DatabaseService().updateHealthData({
        'height': _heightController.text,
        'weight': _weightController.text,
        'bmi': _bmiController.text,
        'conditions': _conditionsController.text,
        'allergies': _allergiesController.text,
        'medications': _medicationsController.text,
        // Store the DateTime object
        'doctorVisits': _doctorVisits,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Health details updated!')),
      );
    } catch (e) {
      print("Error saving health data: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error updating details.')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _calculateBMI() {
    if (_heightController.text.isNotEmpty &&
        _weightController.text.isNotEmpty) {
      double height = double.tryParse(_heightController.text) ?? 0.0;
      double weight = double.tryParse(_weightController.text) ?? 0.0;

      // Convert height to meters
      height = height / 100;

      if (height != 0.0) {
        double bmi = weight / (height * height);
        _bmiController.text = bmi.toStringAsFixed(2);
      }
    } else {
      _bmiController.text = "";
    }
  }

  Future<void> _selectDate(BuildContext context, int index) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _doctorVisits[index]['lastCheckupDate'] != null
          ? (_doctorVisits[index]['lastCheckupDate'] as Timestamp).toDate()
          : DateTime.now(), // Use stored date or current date
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        // Store the DateTime object for later use
        _doctorVisits[index]['lastCheckupDate'] = Timestamp.fromDate(picked);
        // Format the date and update the text field
        _doctorVisits[index]['lastCheckup'] =
            DateFormat('dd-MM-yyyy').format(picked);
      });
    }
  }

  @override
  Widget _buildDoctorVisitCard(int index) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                initialValue: _doctorVisits[index]['doctorName'] ?? "",
                decoration: const InputDecoration(labelText: "Doctor's Name"),
                onChanged: (value) {
                  _doctorVisits[index]['doctorName'] = value;
                },
              ),
              const SizedBox(height: 8),
              // Last Checkup Date (You might want to use a date picker here too)
              TextFormField(
                controller: TextEditingController(text: _doctorVisits[index]['lastCheckup'] ?? ""), // Use a TextEditingController
                decoration: const InputDecoration(labelText: "Last Checkup"),
                onTap: () => _selectDate(context, index), // Call _selectDate with index
                readOnly: true,
              ),
              const SizedBox(height: 8),


              // Reason for Visit
              TextFormField(
                initialValue: _doctorVisits[index]['reasonForVisit'] ?? "",
                decoration:
                const InputDecoration(labelText: "Reason for Visit"),
                onChanged: (value) {
                  _doctorVisits[index]['reasonForVisit'] = value;
                },
              ),
              const SizedBox(height: 8),
              // Medications/Treatments Received
              TextFormField(
                initialValue:
                _doctorVisits[index]['medicationsOrTreatments'] ?? "",
                decoration: const InputDecoration(
                    labelText: "Medications/Treatments Received"),
                onChanged: (value) {
                  _doctorVisits[index]['medicationsOrTreatments'] = value;
                },
              ),
              const SizedBox(height: 8),
          // You can add more fields for doctor's name, specialty, etc.
          // For now, just displaying the calculated next checkup date
              Text(
              'Next Checkup: ${_doctorVisits[index]['nextCheckup'] ?? 'Not Calculated'}',
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8.0, // Space between buttons horizontally
                runSpacing: 8.0, // Space between buttons vertically
                alignment: WrapAlignment.start, // Align buttons to the start of the line
                children: [
                  ElevatedButton(
                    onPressed: () => _calculateNextCheckupDate(7, index),
                    child: const Text("After 7 Days"),
                  ),
                  ElevatedButton(
                    onPressed: () => _calculateNextCheckupDate(14, index),
                    child: const Text("After 14 Days"),
                  ),
                  ElevatedButton(
                    onPressed: () => _calculateNextCheckupDate(30, index),
                    child: const Text("After 30 Days"),
                  ),
                  ElevatedButton(
                    onPressed: () => _calculateNextCheckupDate(90, index),
                    child: const Text("After 90 Days"),
                  ),
                  // ... Add more buttons for different durations
                ],
              ),

              // Add a remove button for each doctor visit card
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {
                  // Remove this doctor visit entry from the list
                  setState(() {
                    _doctorVisits.removeAt(index);
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFD32F2F), // Change button color to red
                ),
                child: const Text("Remove"),
              ),
            ],
          ),
      ),
    );
  }


  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Health Details")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Height
              TextFormField(
                controller: _heightController,
                decoration:
                const InputDecoration(labelText: "Height (cm)"),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your height';
                  }
                  // Example: Height validation (in cm)
                  final height = double.tryParse(value) ?? 0.0;
                  if (height < 50 || height > 300) {
                    return 'Please enter a valid height';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Weight
              TextFormField(
                controller: _weightController,
                decoration:
                const InputDecoration(labelText: "Weight (kg)"),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your weight';
                  }
                  // Example: Weight validation (in kg)
                  final weight = double.tryParse(value) ?? 0.0;
                  if (weight < 10 || weight > 500) {
                    return 'Please enter a valid weight';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // BMI (Calculated - Non-Editable)
              TextFormField(
                controller: _bmiController,
                decoration: const InputDecoration(labelText: "BMI"),
                enabled: false,
              ),
              const SizedBox(height: 16),

              // Medical Conditions with Autocomplete
              TextFormField(
                controller: _conditionsController,
                decoration:
                const InputDecoration(labelText: "Medical Conditions"),
                maxLines: 3,
              ),
              const SizedBox(height: 24),

              // Allergies without Autocomplete
              TextFormField(
                controller: _allergiesController,
                decoration: const InputDecoration(
                  labelText: "Allergies",
                ),
                maxLines: 3,
              ),
              const SizedBox(height: 16),

              // Medications
              TextFormField(
                controller: _medicationsController,
                decoration:
                const InputDecoration(labelText: "Medications"),
                maxLines: 3,
              ),
              const SizedBox(height: 16),

              // Doctor Visits Section
              const SizedBox(height: 24),
              const Text(
                'Doctor Visits',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              ListView.builder(
                shrinkWrap: true, // Important for ListView inside Column
                physics: const NeverScrollableScrollPhysics(), // Disable scrolling for the inner ListView
                itemCount: _doctorVisits.length,
                itemBuilder: (context, index) {
                  return _buildDoctorVisitCard(index);
                },
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _doctorVisits.add({}); // Add a new empty doctor visit entry
                  });
                },
                child: const Text("Add Another Doctor Visit"),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _saveChanges,
                child: const Text("Save Changes"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
