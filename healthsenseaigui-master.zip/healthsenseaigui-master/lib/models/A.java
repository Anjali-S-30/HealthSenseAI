flutterfire configure --project=healthsenseai-bda8d 
i Found 0 Firebase projects.
Failed to fetch your Firebase projects. Fetch failed with this: FirebaseCommandException: An error occured on the Firebase CLI when attempting to run a command.
COMMAND: firebase --version 
ERROR: The FlutterFire CLI currently requires the official Firebase CLI to also be installed, see https://firebase.google.com/docs/cli#install_the_firebase_cli for how to install it.
? Would you like to create a new Firebase project? (y/n) › yes

