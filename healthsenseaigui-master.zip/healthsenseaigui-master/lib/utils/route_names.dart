// /lib/utils/route_names.dart

class RouteNames {
  static const String login = '/login';
  static const String signup = '/signup';
  static const String home = '/home';
  // Add other route names here as you create more screens
  static const String dashboard = '/dashboard';
  static const String pillsInfo = '/pillsInfo';
  static const String diagnoAssist = '/diagnoAssist';
  static const String healthSchemes = '/healthSchemes';
  static const String alerts = '/alerts';
  static const String profile = '/profile';
  static const String healthDetails = '/healthDetails';
}
