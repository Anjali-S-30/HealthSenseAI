import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:healthsenseaigui/screens/alerts_screen.dart';
import 'package:healthsenseaigui/screens/dashboard_screen.dart';
import 'package:healthsenseaigui/screens/diagno_assist_screen.dart';
import 'package:healthsenseaigui/screens/health_details_screen.dart';
import 'package:healthsenseaigui/screens/health_schemes_screen.dart';
import 'package:healthsenseaigui/screens/home_screen.dart';
import 'package:healthsenseaigui/screens/login_screen.dart';
import 'package:healthsenseaigui/screens/pills_info_screen.dart';
import 'package:healthsenseaigui/screens/profile_screen.dart';
import 'package:healthsenseaigui/screens/signup_screen.dart';
import 'package:healthsenseaigui/theme/app_theme.dart';// Import your theme
import 'package:healthsenseaigui/utils/route_names.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );// Initialize Firebase
  runApp(HealthSenseApp());
}

class HealthSenseApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme, // Apply your theme
      home: LoginPage(), // Start with the login screen
      initialRoute: RouteNames.login, // Set the initial route
      routes: {
        RouteNames.login: (context) => LoginPage(),
        RouteNames.signup: (context) => SignUpPage(),
        RouteNames.home: (context) => HomeScreen(),
        RouteNames.dashboard: (context) => DashboardScreen(),
        RouteNames.pillsInfo: (context) => PillsInfoScreen(),
        RouteNames.diagnoAssist: (context) => DiagnoAssistScreen(),
        RouteNames.healthSchemes: (context) => HealthSchemesScreen(),
        RouteNames.alerts: (context) => AlertsScreen(),
        RouteNames.profile: (context) => ProfileScreen(),
        RouteNames.healthDetails: (context) => HealthDetailsScreen(),


        // Add other routes in a similar way
      }
    );
  }
}
